from pptx import Presentation
from pptx.util import Inches, Pt
import os

prs = Presentation()

# Title Slide
title_slide_layout = prs.slide_layouts[0]
slide = prs.slides.add_slide(title_slide_layout)
title = slide.shapes.title
subtitle = slide.placeholders[1]
title.text = "Kubernetes CNI Performance Benchmarking"
subtitle.text = "Comparative Analysis of Calico and Flannel\nGroup 4 (G_4)"

# Introduction Slide
bullet_slide_layout = prs.slide_layouts[1]
slide = prs.slides.add_slide(bullet_slide_layout)
shapes = slide.shapes
title_shape = shapes.title
body_shape = shapes.placeholders[1]
title_shape.text = "Introduction"
tf = body_shape.text_frame
tf.text = "Objective: Benchmark the performance of different Kubernetes CNI plugins."
p = tf.add_paragraph()
p.text = "Focus: Calico vs. Flannel"
p.level = 1
p = tf.add_paragraph()
p.text = "Metrics Evaluated: Latency, Throughput, CPU/Memory utilization"
p.level = 1

# Methodology Slide
slide = prs.slides.add_slide(bullet_slide_layout)
shapes = slide.shapes
title_shape = shapes.title
body_shape = shapes.placeholders[1]
title_shape.text = "Methodology & Setup"
tf = body_shape.text_frame
tf.text = "Test Environment"
p = tf.add_paragraph()
p.text = "Local Kubernetes clusters provisioned via kind."
p.level = 1
p = tf.add_paragraph()
p.text = "Custom manifests for CNI deployment (G_4_calico-cr.yaml, G_4_kube-flannel.yml)."
p.level = 1
p = tf.add_paragraph()
p.text = "Test Scenarios"
p = tf.add_paragraph()
p.text = "Various network loads configured using JSON scenario definitions."
p.level = 1

# Modules
slide = prs.slides.add_slide(bullet_slide_layout)
shapes = slide.shapes
title_shape = shapes.title
body_shape = shapes.placeholders[1]
title_shape.text = "Testing Modules"
tf = body_shape.text_frame
tf.text = "Structured Approach"
p = tf.add_paragraph()
p.text = "Module 1-5: Progressive load testing and benchmarking scenarios."
p.level = 1
p = tf.add_paragraph()
p.text = "Baseline: Initial metrics without heavy network contention."
p.level = 1

# Results Slide
slide = prs.slides.add_slide(bullet_slide_layout)
shapes = slide.shapes
title_shape = shapes.title
body_shape = shapes.placeholders[1]
title_shape.text = "Key Findings & Results"
tf = body_shape.text_frame
tf.text = "Calico"
p = tf.add_paragraph()
p.text = "Demonstrated better performance under high network load and complex policies."
p.level = 1
p = tf.add_paragraph()
p.text = "Flannel"
p = tf.add_paragraph()
p.text = "Simpler setup, but higher overhead in specific scenarios."
p.level = 1

# Conclusion Slide
slide = prs.slides.add_slide(bullet_slide_layout)
shapes = slide.shapes
title_shape = shapes.title
body_shape = shapes.placeholders[1]
title_shape.text = "Conclusion"
tf = body_shape.text_frame
tf.text = "Summary"
p = tf.add_paragraph()
p.text = "Choice of CNI depends heavily on workload requirements."
p.level = 1
p = tf.add_paragraph()
p.text = "Calico is preferable for performance and security policies."
p.level = 1
p = tf.add_paragraph()
p.text = "Flannel is ideal for lightweight, simple deployments."
p.level = 1

prs.save('/Users/shanmukh/IIITD/Sem2/GRS/G_4_Part_B_CNI_Plugins/G_4_CNI_Presentation.pptx')
print("Presentation generated successfully!")
